#include<stdio.h>
#include<fcntl.h>
#include<unistd.h>
#include<sys/stat.h>
#include<sys/types.h>

int main(void)
{
  int f = open("/dev/gpio17_driver", O_RDWR);
  while(1)
{
write(f, "1", 2);
usleep(50000);
write(f, "0", 2);
usleep(50000);
}
}
