#include <linux/fs.h>
#include <linux/cdev.h>
#include <linux/init.h>
#include <linux/device.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/uaccess.h>
#include <linux/io.h>

#define DRIVER_NAME "gpio17_driver"
#define DRIVER_CLASS "gpio_class"
#define BCM2711_GPIO_ADDRESS 0xFE200000  // Base address GPIO trên RPi 4
#define GPIO_PIN 17  // Sử dụng GPIO 17

static dev_t dev_no;
static struct cdev dev;
static struct class *cls;
static void __iomem *gpio_base;  // Con trỏ đến vùng nhớ GPIO

// Hàm thiết lập GPIO 17 thành output
static void gpio_init(void) {
    unsigned int *gpio_sel_reg = (unsigned int *)(gpio_base + (GPIO_PIN / 10) * 4);
    unsigned int shift = (GPIO_PIN % 10) * 3;
    *gpio_sel_reg &= ~(0b111 << shift);  // Xóa cấu hình cũ
    *gpio_sel_reg |= (0b001 << shift);   // Đặt GPIO 17 là output
}

// Hàm bật GPIO 17
static void gpio_set(void) {
    unsigned int *gpio_set_reg = (unsigned int *)(gpio_base + 0x1C);
    *gpio_set_reg = (1 << GPIO_PIN);
}

// Hàm tắt GPIO 17
static void gpio_clr(void) {
    unsigned int *gpio_clr_reg = (unsigned int *)(gpio_base + 0x28);
    *gpio_clr_reg = (1 << GPIO_PIN);
}

// Hàm mở thiết bị
static int device_open(struct inode *device_file, struct file *instance) {
    printk("GPIO17 Driver: Opened\n");
    return 0;
}

// Hàm đóng thiết bị
static int device_close(struct inode *device_file, struct file *instance) {
    printk("GPIO17 Driver: Closed\n");
    return 0;
}

// Hàm ghi dữ liệu vào driver
static ssize_t device_write(struct file *file, const char *user_buffer, size_t size, loff_t *offs) {
    char user_data[10];
    memset(user_data, 0, sizeof(user_data));

    if (copy_from_user(user_data, user_buffer, size)) {
        return -EFAULT;
    }

    printk("GPIO17 Driver: Received command: %s\n", user_data);

    if (strncmp(user_data, "1", 1) == 0) {
        printk("GPIO17 ON\n");
        gpio_set();
    } else if (strncmp(user_data, "0", 1) == 0) {
        printk("GPIO17 OFF\n");
        gpio_clr();
    }

    return size;
}

// Cấu trúc file_operations cho driver
static struct file_operations fops = {
    .owner = THIS_MODULE,
    .write = device_write,
    .open = device_open,
    .release = device_close,
};

// Hàm khởi tạo module
static int __init device_driver_init(void) {
    if (alloc_chrdev_region(&dev_no, 0, 1, DRIVER_NAME) < 0) {
        printk("GPIO17 Driver: Failed to allocate device number\n");
        return -1;
    }
    printk("GPIO17 Driver: Major - %d, Minor - %d\n", MAJOR(dev_no), MINOR(dev_no));

    if ((cls = class_create(DRIVER_CLASS)) == NULL) {
        unregister_chrdev_region(dev_no, 1);
        printk("GPIO17 Driver: Failed to create class\n");
        return -1;
    }

    if (device_create(cls, NULL, dev_no, NULL, DRIVER_NAME) == NULL) {
        class_destroy(cls);
        unregister_chrdev_region(dev_no, 1);
        printk("GPIO17 Driver: Failed to create device file\n");
        return -1;
    }

    cdev_init(&dev, &fops);
    if (cdev_add(&dev, dev_no, 1) < 0) {
        device_destroy(cls, dev_no);
        class_destroy(cls);
        unregister_chrdev_region(dev_no, 1);
        printk("GPIO17 Driver: Failed to register device\n");
        return -1;
    }

    gpio_base = ioremap(BCM2711_GPIO_ADDRESS, PAGE_SIZE);
    if (!gpio_base) {
        printk("GPIO17 Driver: Failed to map GPIO memory\n");
        return -1;
    }

    gpio_init();
    printk("GPIO17 Driver: Initialized successfully\n");

    return 0;
}

// Hàm giải phóng module
static void __exit device_driver_exit(void) {
    iounmap(gpio_base);
    cdev_del(&dev);
    device_destroy(cls, dev_no);
    class_destroy(cls);
    unregister_chrdev_region(dev_no, 1);
    printk("GPIO17 Driver: Unloaded successfully\n");
}

module_init(device_driver_init);
module_exit(device_driver_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Your Name");
MODULE_DESCRIPTION("GPIO 17 LED Blink Driver for Raspberry Pi 4");

